import { LightningElement, wire } from 'lwc';
import getActiveSession from '@salesforce/apex/SessionManagementController.getActiveSession';
import loggedInUserId from '@salesforce/user/Id';
export default class ManageUserSession extends LightningElement {
    componentRendered = false;
    @wire(getActiveSession, { userId: loggedInUserId })
    wiredResult({ error, data }) {
        if (data) {
            this.activeSessions = data;
            console.log('activeSessions ' + JSON.stringify(this.activeSessions));
        } else if (error) {
            this.activeSessions = undefined;
        }
    }
}