package com.learnjava.ranjan;

public class BubbleSort {

	public static void main(String[] args) {
		int array [] = {24,2,45,20,56,75,2,56,99,53,12};
		BubbleSort ob = new BubbleSort(); 
	    ob.sort(array);
	    for(int i:array){
	        System.out.print(i);
	        System.out.print(" ");
	        }

	}
	
	public void sort(int[] inputArray) {
		int length = inputArray.length;
		Boolean  isSwapped = false ;
		
		for(int i = 0 ; i < length -1 ;i ++) {
			isSwapped = false;
			for(int j = 0 ; j< length - i - 1;j ++) {
				if(inputArray[j] > inputArray[j+1]) {
					swap(inputArray,j,j+1);	
					isSwapped = true;
				}
			}
			if(!isSwapped) break;
		}
		
	}
	private void swap(int[] inputArray, int i, int j) {
		
		int temp = inputArray[i]; 
		inputArray[i] = inputArray[j]; 
		inputArray[j] = temp; 
	}
	
	
}
