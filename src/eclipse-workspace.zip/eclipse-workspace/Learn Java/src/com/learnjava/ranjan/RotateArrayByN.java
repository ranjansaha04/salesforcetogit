package com.learnjava.ranjan;

import java.util.ArrayList;

public class RotateArrayByN {
	public static ArrayList<Integer> rotateArray(ArrayList<Integer> A, int B) {
        ArrayList<Integer> ret = new ArrayList<Integer>();
		int size = A.size();
		if(B>=size){
			B = B % size;
		}
        for (int i = 0; i < size; i++) {
			int index = (i+B)>=size? (i+B-size) : (i+B);
            ret.add(A.get(index));
        }
        return ret;
    }
	
	public static ArrayList<Integer> rotateArray2(ArrayList<Integer> A, int B) {
        ArrayList<Integer> ret = new ArrayList<Integer>();
        for (int i = 0; i < A.size(); i++) {
            ret.add(A.get((i + B) % A.size()));
        }
        return ret;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> myNumbers = new ArrayList<Integer>();
		myNumbers.add(33);
	    myNumbers.add(15);
	    myNumbers.add(20);
	    myNumbers.add(34);
	    myNumbers.add(8);
	    myNumbers.add(12);
	    
	    ArrayList<Integer> myNumbersReturned =  rotateArray2(myNumbers,3);
	    
	    for (int i : myNumbersReturned) {
	        System.out.println(i);
	    }
	}

}
