package com.learnjava.ranjan;

public class GoogleSecondRound2 {

	public static int calculateSum(int[] numberArray, int k) {
		int N = numberArray.length;
		int sum = 0;
		int result =0 ;
		// calculate sum from left side
		for(int i = 0; i<k;i++) {
			result += numberArray[i];
		}
		sum = result;
		
		for(int i = 0; i < k; i++){
			System.out.println("remove "+ (k - 1 - i));
			System.out.println("add "+ (N - 1 - i));
            sum = sum - numberArray[k - 1 - i];
            sum = sum + numberArray[N - 1- i];
            result = Math.max(result,sum);
        }
		return result;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] inputArray = new int[] {1,4,3,9};
        int output = calculateSum(inputArray,2);
        System.out.println("output"+output);
	}
}
