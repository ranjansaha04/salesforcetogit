package com.learnjava.ranjan;

public class MergeSort {
	private int[] inputArray;
    private int[] auxArray;
    private int length;
	public void sort(int [] arr) {
		this.inputArray = arr;
		this.length = arr.length;
		this.auxArray = new int[length];
		doMergeSort(0,length -1);
		
	}
	
	private void doMergeSort(int startIndex, int endIndex) {
        
        if (startIndex < endIndex) {
            int middle = startIndex + (endIndex - startIndex) / 2;
            // Below step sorts the left side of the inputArray
            doMergeSort(startIndex, middle);
            // Below step sorts the right side of the inputArray
            doMergeSort(middle + 1, endIndex);
            // Now merge both sides
            merge(startIndex, middle, endIndex);
        }
    }
	
	public void merge(int startIndex,int mid,int endIndex) {
		
		for (int i = startIndex; i <= endIndex; i++) {
			auxArray[i] = inputArray[i];
        }
		
		int i = startIndex;
        int j = mid + 1;
        int k = startIndex;
        System.out.println("i : "+ i + " j :" + j + " k :" + k);
        System.out.println("start : "+ startIndex + " mid :" + mid + " end :" + endIndex);
		// traverse both inputArrays and in each iteration add 
		//smaller of both elements in temp 
		while(i <= mid && j <= endIndex) {
			if(auxArray[i] <= auxArray[j]) {
				inputArray[k] = auxArray[i];
				System.out.println("element less than  :" +inputArray[k]);
				i++;
			}
			else {
				inputArray[k] = auxArray[j];
				System.out.println("element greater  than  :" +inputArray[k]);
				j++;
			}

			k++;
		}
		
		// add elements left in the first interval 
		while(i <= mid) {
			inputArray[k] = auxArray[i];
			System.out.println("mid criteria  :" +inputArray[k]);
			k++;
			i++;
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = { 12, 11, 13, 5 }; 
		MergeSort ob = new MergeSort(); 
        ob.sort(arr);
        for(int i:arr){
            System.out.print(i);
            System.out.print(" ");
        }
	}

}
