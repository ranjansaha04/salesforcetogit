package com.learnjava.ranjan;

import java.util.Random;

public class QuickSort {
    
	public void sort(int[] inputArray) {
		quickSort(inputArray,0,(inputArray.length -1 ));
	}
	
	public void quickSort(int[] inputArray, int startIndex, int endIndex) {
		//24,2,45,20,56,75,2,56,99,53,12
		int i = startIndex;
        int j = endIndex;
        
        // calculate pivot number, I am taking pivot as middle index number
        //int pivot = inputArray[startIndex+(endIndex-startIndex)/2];
        Random rand = new Random();
        int pivotIndex = startIndex + rand.nextInt(endIndex - startIndex + 1);
        int pivot = inputArray[pivotIndex];
        System.out.println("pivot element "+pivot);
        while (i <= j) {
            /**
             * In each iteration, we will identify a number from left side which 
             * is greater then the pivot value, and also we will identify a number 
             * from right side which is less then the pivot value. Once the search 
             * is done, then we exchange both numbers.
             */
            while (inputArray[i] < pivot) {
                i++;
            }
            while (inputArray[j] > pivot) {
                j--;
            }
            if (i <= j) {
            	//System.out.println("i "+i);
            	//System.out.println("j "+j);
                swap(inputArray,i, j);
                i++;
                j--;
            }
        }
        for(int ii:inputArray){
            System.out.print(ii);
            System.out.print(" ");
        }
        // call quickSort() method recursively
        if (startIndex < j) {
        	quickSort(inputArray,startIndex, j);
        }            
        if (i < endIndex) {
        	quickSort(inputArray,i, endIndex);
        }
            
	}
	private void swap(int[] inputArray, int i, int j) {
		
		int temp = inputArray[i]; 
		inputArray[i] = inputArray[j]; 
		inputArray[j] = temp; 
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int array [] = {24,2,45,20,56,75,2,56,99,53,12};
		QuickSort ob = new QuickSort(); 
        ob.sort(array);
        for(int i:array){
            System.out.print(i);
            System.out.print(" ");
        }
	}

}
