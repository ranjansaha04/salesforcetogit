package com.learnjava.ranjan;
//this solution is not correct
public class GoogleSecondRound {
    
	public static int calculateSum(int[] numberArray, int k) {
		int N = numberArray.length;
		int startSum = 0, endSum = 0;
		int result =0 ;
		// calculate sum from left side
		for(int i = 0; i<k;i++) {
			startSum += numberArray[i];
		}
		for(int i = N-1; i>(N-1-k);i--) {
			endSum += numberArray[i];
		}
		result = (startSum > endSum) ? startSum : endSum;
		return result;
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] inputArray = new int[] {10,3,4,9,3,4,7,9};
        int output = calculateSum(inputArray,4);
        System.out.println("output"+output);
	}

}
