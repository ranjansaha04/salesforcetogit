	package com.learnjava.ranjan;
	
	public class SelectionSort {
		public void sort(int[] inputArray) {
			int length = inputArray.length;
			int minimumIndex = 0 ;
			
			for(int i = 0 ; i < length -1 ;i ++) {
				minimumIndex = i;
				for(int j = i+1 ; j< length ;j ++) {
					if(inputArray[minimumIndex] > inputArray[j]) {
						minimumIndex = j;						
					}
				}
				if(i!=minimumIndex)
				swap(inputArray,i,minimumIndex);
			}
			
		}
		
	private void swap(int[] inputArray, int i, int j) {
			
			int temp = inputArray[i]; 
			inputArray[i] = inputArray[j]; 
			inputArray[j] = temp; 
		}
		public static void main(String[] args) {
			// TODO Auto-generated method stub
		int array [] = {24,2,45,20,56,75,2,56,99,53,12};
		SelectionSort ob = new SelectionSort(); 
	    ob.sort(array);
	    for(int i:array){
	        System.out.print(i);
	        System.out.print(" ");
	        }
		}
	
	}
