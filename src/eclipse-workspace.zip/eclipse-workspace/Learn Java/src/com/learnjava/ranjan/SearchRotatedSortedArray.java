package com.learnjava.ranjan;
//33. Search in Rotated Sorted Array
public class SearchRotatedSortedArray {
	/*You are given an integer array nums sorted in ascending order, and an integer target.

	Suppose that nums is rotated at some pivot unknown to you beforehand (i.e., [0,1,2,4,5,6,7] might become [4,5,6,7,0,1,2]).

	If target is found in the array return its index, otherwise, return -1.
	*/
	public static int search(int[] nums, int target) {
        int inputSize = nums.length;
        if(nums == null || inputSize == 0) return -1;
        
        //find pivot index
        int left = 0;
        int right = inputSize - 1;
        while(left<=right) {
        	int midpoint = left + (right - left)/2;
        	if(target == nums[midpoint]) {
        		return midpoint;
        	}
        	//check side wise element order
        	if(nums[midpoint] <= nums[right]) {
        		 // right half of the array is sorted
        		if(target > nums[midpoint] && target <=nums[right]) {
        			left = midpoint + 1;
        		}
        		else {
        			right = midpoint - 1;
        		}
        	}
        	else {
        		 // left half of the array is sorted
        		if(target >= nums[left] && target <nums[midpoint]) {
        			right = midpoint -1;
        		}
        		else {
        			left = midpoint +1;
        		}
        	}
        }
        return -1;
                
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] input = {4,5,6,7,0,1,2}; 
		int result = search(input,0);
		System.out.println(result);
	}

}
