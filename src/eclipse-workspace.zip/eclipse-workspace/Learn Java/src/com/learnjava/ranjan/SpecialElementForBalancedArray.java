package com.learnjava.ranjan;

import java.util.ArrayList;

public class SpecialElementForBalancedArray {
	public static int solve(ArrayList<Integer> a) {
		if (a == null || a.size() == 2) {
            return 0;
        } 
        
        if (a.size() == 1) {
            return 1;
        }
		int totalEven = 0;
        int totalOdd = 0;
		for (int i=0; i< a.size(); i++) {
           if (i%2 == 0) {
               totalEven += a.get(i);
           } else {
               totalOdd += a.get(i);
           }
        }
		int lEven = 0;
        int rEven = 0;
        int lOdd = 0;
        int rOdd = 0;
        int count = 0;
		for(int i=0; i<a.size(); i++){
			if(i%2 == 0){
				System.out.println("totalEven : "+totalEven);
				System.out.println("lEven : "+lEven);
				System.out.println("a.get(i) : "+a.get(i));
				rEven = totalEven - lEven - a.get(i);
				System.out.println("rEven : "+rEven);
				rOdd = totalOdd - lOdd;
				System.out.println("rOdd ****: "+rOdd);
				if ((lEven + rOdd) == (lOdd + rEven)) {
					count++;
				}
				lEven += a.get(i);
			}else{
				System.out.println("lEven : "+lEven);
				rEven = totalEven - lEven;
				System.out.println("rOdd : "+rEven);
				System.out.println("totalOdd : "+totalOdd);
				System.out.println("lOdd : "+lOdd);
				System.out.println("a.get(i) : "+a.get(i));
				rOdd = totalOdd -lOdd - a.get(i);
				if ((lEven + rOdd) == (lOdd + rEven)) {
					count++;
				}
				lOdd += a.get(i);
			}
		}
		return count;
    }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer> myNumbers = new ArrayList<Integer>();
		myNumbers.add(5);
	    myNumbers.add(5);
	    myNumbers.add(2);
	    myNumbers.add(5);
	    myNumbers.add(8);
	    
	    int count =  solve(myNumbers);
	    System.out.println(count);
	}

}
