package com.tutorial.ranjan;

import java.math.BigDecimal;

public class Employee extends Person {
	private String taxPayerIdNumber;
	private String employeeNumber;
	private BigDecimal salary;
	
	public Employee() {
		super();
	}

	public Employee(String name, int age, int height, int weight, String gender) {
		super(name, age, height, weight, gender);
	}

	public String getTaxPayerIdNumber() {
		return taxPayerIdNumber;
	}

	public void setTaxPayerIdNumber(String taxPayerIdNumber) {
		this.taxPayerIdNumber = taxPayerIdNumber;
	}

	public String getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(String employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}

	@Override
	public void printAudit(StringBuilder buffer) {
		/*super.printAudit(buffer);
		buffer.append("taxPayerIdNumber=");
		buffer.append(getTaxPayerIdNumber());
		buffer.append(",");
		buffer.append("employeeNumber=");
		buffer.append(getEmployeeNumber());
		buffer.append(",");
		buffer.append("salary=");
		buffer.append(getSalary().setScale(2).toPlainString());*/
		buffer.append(toString());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((employeeNumber == null) ? 0 : employeeNumber.hashCode());
		result = prime * result + ((salary == null) ? 0 : salary.hashCode());
		result = prime * result + ((taxPayerIdNumber == null) ? 0 : taxPayerIdNumber.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (employeeNumber == null) {
			if (other.employeeNumber != null)
				return false;
		} else if (!employeeNumber.equals(other.employeeNumber))
			return false;
		if (salary == null) {
			if (other.salary != null)
				return false;
		} else if (!salary.equals(other.salary))
			return false;
		if (taxPayerIdNumber == null) {
			if (other.taxPayerIdNumber != null)
				return false;
		} else if (!taxPayerIdNumber.equals(other.taxPayerIdNumber))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return super.toString() + "Employee [taxPayerIdNumber=" + taxPayerIdNumber + ", employeeNumber=" + employeeNumber + ", salary="
				+ salary + "]";
	}

}
