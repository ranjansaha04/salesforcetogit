package com.tutorial.ranjan;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.util.logging.Logger;

import org.junit.jupiter.api.Test;

class EmployeeTest {

	@Test
	void testPrintAuditLogger() {
		Employee e = new Employee("Ranjan",29,181,76,"Male");
		e.setEmployeeNumber("A123");
		e.setSalary(BigDecimal.valueOf(80000L));
		e.setTaxPayerIdNumber("123-45-6789");
		
		Logger logger = Logger.getLogger(EmployeeTest.class.getName());
		e.printAudit(logger);
	}
	
	@Test
	public void yetAnotherTest() {
	  Logger l = Logger.getLogger(Employee.class.getName());
	  Employee employee1 = new Employee();
	  employee1.setName("J Smith");
	  Employee employee2 = new Employee();
	  employee2.setName("J Smith");
	  l.info("Q: employee1 == employee2?      A: " + (employee1 == employee2));
	  l.info("Q: employee1.equals(employee2)? A: " + employee1.equals(employee2));    
	}

}
