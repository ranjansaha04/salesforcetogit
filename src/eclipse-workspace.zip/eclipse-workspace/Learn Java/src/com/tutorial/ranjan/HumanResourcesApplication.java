package com.tutorial.ranjan;

import java.math.BigDecimal;
import java.util.logging.Logger;

public class HumanResourcesApplication {
	private static final Logger log = Logger.getLogger(HumanResourcesApplication.class.getName());
	public static void main(String[] args) {
		Employee e = new Employee();
	    e.setName("J Smith");
	    e.setEmployeeNumber("A123");
		e.setSalary(BigDecimal.valueOf(80000L));
		e.setTaxPayerIdNumber("123-45-6789");
	    e.printAudit(log);

	}

}
