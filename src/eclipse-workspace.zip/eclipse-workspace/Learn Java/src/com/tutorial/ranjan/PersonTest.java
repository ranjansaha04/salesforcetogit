package com.tutorial.ranjan;

import static org.junit.jupiter.api.Assertions.*;

import java.util.logging.Logger;

import org.junit.jupiter.api.Test;

class PersonTest {

	@Test
	void testPerson() {
		Person p = new Person("Ranjan",29,181,76,"Male");
		Logger l = Logger.getLogger(Person.class.getName());
		l.info("Created Person object named : " + p.getName());
		
		assertEquals("Ranjan",p.getName());
		assertEquals(29,p.getAge());
		assertEquals(181,p.getHeight());
		assertEquals(76,p.getWeight());
		assertEquals("Male",p.getGender());
	}

}
