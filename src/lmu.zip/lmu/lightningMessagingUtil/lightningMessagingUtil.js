import { api, LightningElement } from 'lwc';
import FORM_FACTOR from '@salesforce/client/formFactor';
import illustrations from '@salesforce/resourceUrl/illustrations';
export default class LightningMessagingUtil extends LightningElement {
    @api messageType;
    @api messageTheme;
    @api messageTitle;
    @api messageBody;
    @api dismissible;    
    @api maxWidth;
    @api iconSize;
    @api promptButtonLabel;
    @api illustrationName;
    display = true;
    handleClose(event) {
        this.display = false;
    }

    hanldePromptButton(event) {
        this.display = false;
    }

    handleKeyPress(event) {
        console.log(event.which);
        if(event.which === 48) {
            this.display = false;
        }
    }
    get isAlert() {
        return this.messageType === 'alert';
    }

    get isPrompt() {
        return this.messageType === 'prompt';
    }

    get isIllustration() {
        return this.messageType === 'illustration';
    }

    get alertMessageCSS() {
        let classList;
        switch (this.messageTheme) {
            case 'warn':
                classList = 'slds-notify slds-notify_alert slds-alert_warning';
                break;
            case 'error':
                classList = 'slds-notify slds-notify_alert slds-alert_error';
                break;
            case 'offline':
                classList = 'slds-notify slds-notify_alert slds-alert_offline';
                break;    
            default:
                classList = 'slds-notify slds-notify_alert';
                break;
        }
        return classList;
    }

    get alertIcons() {
        let iconName;
        switch (this.messageTheme) {
            case 'warn':
                iconName = 'utility:warning';
                break;
            case 'error':
                iconName = 'utility:error';
                break;
            case 'offline':
                iconName = 'utility:offline';
                break;    
            default:
                iconName = '';
                break;
        }
        return iconName;
    }

    get promptHeaderCSS() {
        let classList;
        switch (this.messageTheme) {
            case 'warn':
                classList = 'slds-modal__header slds-theme_warning';
                break;
            case 'error':
                classList = 'slds-modal__header slds-theme_error';
                break;
            case 'offline':
                classList = 'slds-modal__header slds-theme_offline';
                break;    
            default:
                classList = 'slds-modal__header slds-theme_info';
                break;
        }
        return classList;
    }

    get illustrationSrc() {
        return illustrations+'/illustrations/'+this.illustrationName + '.jpg';
    }
}